# Website for The Institute for Ethical AI & Machine Learning 

This repository contains the live website for The Institute for Ethical AI & Machine Learning, which includes:
* Information about the institute
* The Ethical ML Network
* The 8 Machine Learning Principles

## Open Source

This repository is open for contributions by the community. 

You can either submit a [pull request](https://github.com/EthicalML/ethical/pulls), or submit an [issue/request](https://github.com/EthicalML/ethical/issues).

